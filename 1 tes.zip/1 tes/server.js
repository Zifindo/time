const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');

const ROOT = __dirname;
loadEnvironmentFile();

const PORT = Number(process.env.PORT) || 3000;
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const MAX_BODY_BYTES = 32 * 1024;
const MAX_HISTORY_ITEMS = 20;

const server = http.createServer(async (request, response) => {
  const requestUrl = new URL(request.url, 'http://localhost');

  if (requestUrl.pathname === '/api/chat') {
    if (request.method !== 'POST') {
      sendJson(response, 405, { error: 'Gunakan metode POST.' }, { Allow: 'POST' });
      return;
    }
    await handleChat(request, response);
    return;
  }

  if (request.method !== 'GET' && request.method !== 'HEAD') {
    sendJson(response, 405, { error: 'Metode tidak didukung.' }, { Allow: 'GET, HEAD' });
    return;
  }

  serveStaticFile(requestUrl.pathname, request.method, response);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`ruangcatat berjalan di http://127.0.0.1:${PORT}`);
  if (!getGeminiApiKey()) {
    console.warn('GEMINI_API_KEY belum diatur. Chat Gemini akan menampilkan error sampai key tersedia di .env.');
  }
});

async function handleChat(request, response) {
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    sendJson(response, 503, { error: 'GEMINI_API_KEY belum diatur pada backend.' });
    return;
  }

  let payload;
  try {
    payload = await readJsonBody(request);
  } catch (error) {
    const status = error instanceof Error && error.message === 'Ukuran request terlalu besar.' ? 413 : 400;
    sendJson(response, status, { error: error instanceof Error ? error.message : 'Request JSON tidak valid.' });
    return;
  }

  const validationError = validateChatPayload(payload);
  if (validationError) {
    sendJson(response, 400, { error: validationError });
    return;
  }

  const history = payload.history.map(item => ({
    role: item.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: item.content }]
  }));
  history.push({ role: 'user', parts: [{ text: payload.message }] });

  let geminiResponse;
  try {
    geminiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': apiKey
        },
        body: JSON.stringify({ contents: history }),
        signal: AbortSignal.timeout(45_000)
      }
    );
  } catch (error) {
    console.error('Gagal menghubungi Gemini:', error);
    sendJson(response, 502, { error: 'Backend tidak dapat terhubung ke Gemini.' });
    return;
  }

  let result;
  try {
    result = await geminiResponse.json();
  } catch (error) {
    console.error('Respons Gemini bukan JSON yang valid:', error);
    sendJson(response, 502, { error: 'Backend menerima respons Gemini yang tidak valid.' });
    return;
  }

  if (!geminiResponse.ok) {
    const message = result?.error?.message;
    console.error(`Gemini API mengembalikan status ${geminiResponse.status}:`, message || 'Tanpa detail error.');
    let userMessage = `Permintaan Gemini gagal (status ${geminiResponse.status}).`;
    if (geminiResponse.status === 401 || geminiResponse.status === 403) {
      userMessage = 'Gemini menolak API key. Periksa key baru dan akses Gemini API pada Google AI Studio.';
    } else if (geminiResponse.status === 429) {
      userMessage = 'Kuota atau batas permintaan Gemini tercapai. Periksa kuota API dan coba lagi nanti.';
    } else if (geminiResponse.status === 400) {
      userMessage = 'Gemini menolak request. Periksa nama model dan format percakapan.';
    }
    sendJson(response, geminiResponse.status === 429 ? 429 : 502, {
      error: userMessage
    });
    return;
  }

  const reply = result?.candidates?.[0]?.content?.parts
    ?.filter(part => typeof part.text === 'string')
    .map(part => part.text)
    .join('')
    .trim();

  if (!reply) {
    console.error('Gemini tidak mengembalikan teks jawaban.');
    sendJson(response, 502, { error: 'Gemini tidak mengembalikan teks jawaban.' });
    return;
  }

  sendJson(response, 200, { reply });
}

function getGeminiApiKey() {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'PASTE_YOUR_GEMINI_API_KEY_HERE') return null;
  return apiKey;
}

function validateChatPayload(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return 'Body request harus berupa object JSON.';
  }
  if (typeof payload.message !== 'string' || !payload.message.trim() || payload.message.length > 4000) {
    return 'Pesan harus berisi 1 sampai 4000 karakter.';
  }
  if (payload.history !== undefined && !Array.isArray(payload.history)) {
    return 'Riwayat chat harus berupa array.';
  }

  const history = payload.history || [];
  if (history.length > MAX_HISTORY_ITEMS) {
    return `Riwayat chat maksimal ${MAX_HISTORY_ITEMS} pesan.`;
  }
  for (const item of history) {
    if (!item || !['user', 'assistant'].includes(item.role)
      || typeof item.content !== 'string' || !item.content.trim() || item.content.length > 4000) {
      return 'Format riwayat chat tidak valid.';
    }
  }
  return null;
}

async function readJsonBody(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw new Error('Ukuran request terlalu besar.');
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new Error('Body harus berupa JSON yang valid.');
  }
}

function serveStaticFile(pathname, method, response) {
  let decodedPath;
  try {
    decodedPath = decodeURIComponent(pathname);
  } catch {
    sendJson(response, 400, { error: 'Path URL tidak valid.' });
    return;
  }

  const relativePath = decodedPath === '/' ? 'index.html' : decodedPath.slice(1);
  const filePath = path.resolve(ROOT, relativePath);
  const relativeToRoot = path.relative(ROOT, filePath);
  if (relativeToRoot.startsWith('..') || path.isAbsolute(relativeToRoot)) {
    sendJson(response, 403, { error: 'Akses file ditolak.' });
    return;
  }
  if (relativeToRoot.split(path.sep).some(segment => segment.startsWith('.'))) {
    sendJson(response, 404, { error: 'File tidak ditemukan.' });
    return;
  }

  fs.stat(filePath, (statError, stats) => {
    if (statError || !stats.isFile()) {
      sendJson(response, 404, { error: 'File tidak ditemukan.' });
      return;
    }
    const contentType = getContentType(filePath);
    response.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': stats.size,
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'no-cache'
    });
    if (method === 'HEAD') {
      response.end();
      return;
    }
    fs.createReadStream(filePath).pipe(response);
  });
}

function getContentType(filePath) {
  const extension = path.extname(filePath).toLowerCase();
  return {
    '.css': 'text/css; charset=utf-8',
    '.html': 'text/html; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8'
  }[extension] || 'application/octet-stream';
}

function sendJson(response, status, body, headers = {}) {
  const encoded = JSON.stringify(body);
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    ...headers
  });
  response.end(encoded);
}

function loadEnvironmentFile() {
  const envPath = path.join(ROOT, '.env');
  let content;
  try {
    content = fs.readFileSync(envPath, 'utf8');
  } catch (error) {
    if (error.code === 'ENOENT') return;
    throw error;
  }

  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const separator = trimmed.indexOf('=');
    if (separator < 1) continue;
    const name = trimmed.slice(0, separator).trim();
    let value = trimmed.slice(separator + 1).trim();
    if (!/^[A-Z_][A-Z0-9_]*$/.test(name) || process.env[name]) continue;
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    process.env[name] = value;
  }
}
