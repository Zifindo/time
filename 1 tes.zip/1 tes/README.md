# ruangcatat

## Menjalankan aplikasi dan Asisten Gemini

1. Pastikan Node.js 18 atau lebih baru tersedia.
2. Salin `.env.example` menjadi `.env` (PowerShell: `Copy-Item .env.example .env`).
3. Buat API key baru di Google AI Studio, lalu ganti nilai placeholder `GEMINI_API_KEY` di `.env`. Placeholder tidak dapat dipakai untuk meminta jawaban.
4. Jalankan `node server.js` dari folder proyek.
5. Buka `http://127.0.0.1:3000` di browser.

Server menggunakan model `gemini-2.5-flash` secara default. Model dan port dapat diubah melalui `GEMINI_MODEL` dan `PORT` di `.env`. Jangan menaruh API key di `app.js`, HTML, browser, atau URL. File `.env` sudah dikecualikan oleh `.gitignore`.

Setelah mengubah `.env`, hentikan dan jalankan ulang server agar konfigurasi dibaca kembali. Jika key pernah ditaruh di file contoh, chat, atau tempat yang bisa dibagikan, cabut key tersebut di Google AI Studio dan gunakan key baru.

Chat menggunakan backend lokal `POST /api/chat` dengan body `{ "message": "...", "history": [] }`. Backend mengirim permintaan ke Gemini menggunakan header `x-goog-api-key` dan membalas `{ "reply": "..." }`.
