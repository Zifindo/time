const STORAGE_KEY = 'ruangcatat-notes-v1';
const SESSION_KEY = 'ruangcatat-demo-session-v1';
const colors = ['yellow', 'pink', 'blue', 'green'];
const colorNames = { yellow: 'Mentega', pink: 'Melon', blue: 'Langit', green: 'Mint' };
const starterNotes = [
  { id: 'welcome-1', title: 'Mulai dari sini', body: 'Simpan ide, rencana kecil, atau hal yang ingin kamu ingat. Catatanmu akan tetap ada di perangkat ini.', color: 'yellow', pinned: true, createdAt: Date.now() - 3600000, updatedAt: Date.now() - 3600000 },
  { id: 'welcome-2', title: 'Ruang untuk ide', body: 'Klik kartu untuk mengedit. Gunakan titik di kanan atas untuk pilihan lainnya.', color: 'green', pinned: false, createdAt: Date.now() - 7200000, updatedAt: Date.now() - 7200000 },
  { id: 'welcome-3', title: 'Satu hal hari ini', body: 'Buat catatan pertama yang benar-benar milikmu. Pilih warna, tulis apa saja, lalu sematkan yang penting.', color: 'pink', pinned: false, createdAt: Date.now() - 10800000, updatedAt: Date.now() - 10800000 }
];

const grid = document.querySelector('#notes-grid');
const dialog = document.querySelector('#editor-dialog');
const loginScreen = document.querySelector('#login-screen');
const notesApp = document.querySelector('#notes-app');
const loginForm = document.querySelector('#login-form');
const loginEmail = document.querySelector('#login-email');
const loginPassword = document.querySelector('#login-password');
const chatDialog = document.querySelector('#chat-dialog');
const chatMessages = document.querySelector('#chat-messages');
const chatForm = document.querySelector('#chat-form');
const chatInput = document.querySelector('#chat-input');
const chatSend = document.querySelector('#chat-send');
const chatSettingsToggle = document.querySelector('#chat-settings-toggle');
const chatSettings = document.querySelector('#chat-settings');
const titleInput = document.querySelector('#note-title');
const bodyInput = document.querySelector('#note-body');
const searchInput = document.querySelector('#search-input');
const emptyState = document.querySelector('#empty-state');
const showApp = sessionStorage.getItem(SESSION_KEY) === 'active';
loginScreen.hidden = showApp;
notesApp.hidden = !showApp;
let notes = loadNotes();
let activeFilter = 'all';
let activeColor = 'all';
let activeView = 'grid';
let editingId = null;
let selectedColor = 'yellow';
let chatHistory = [];

loginForm.addEventListener('submit', event => {
  event.preventDefault();
  sessionStorage.setItem(SESSION_KEY, 'active');
  loginPassword.value = '';
  loginScreen.hidden = true;
  notesApp.hidden = false;
});
document.querySelector('#toggle-password').addEventListener('click', event => {
  const button = event.currentTarget;
  const showPassword = loginPassword.type === 'password';
  loginPassword.type = showPassword ? 'text' : 'password';
  button.textContent = showPassword ? 'Sembunyikan' : 'Lihat';
  button.setAttribute('aria-label', showPassword ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi');
  button.setAttribute('aria-pressed', String(showPassword));
});
document.querySelector('#logout-button').addEventListener('click', () => {
  sessionStorage.removeItem(SESSION_KEY);
  if (chatDialog.open) chatDialog.close();
  chatHistory = [];
  chatMessages.replaceChildren();
  appendChatMessage('assistant', 'Hai! Saya bisa membantu mencari ide, merangkum, atau menyusun tulisan. Apa yang ingin kamu kerjakan?');
  loginScreen.hidden = false;
  notesApp.hidden = true;
  loginForm.reset();
  loginPassword.type = 'password';
  const passwordToggle = document.querySelector('#toggle-password');
  passwordToggle.textContent = 'Lihat';
  passwordToggle.setAttribute('aria-label', 'Tampilkan kata sandi');
  passwordToggle.setAttribute('aria-pressed', 'false');
  loginEmail.focus();
});
document.querySelector('#chat-launcher').addEventListener('click', () => {
  chatDialog.showModal();
  chatInput.focus();
});
document.querySelector('#chat-close').addEventListener('click', () => chatDialog.close());
chatSettingsToggle.addEventListener('click', () => {
  const isExpanded = chatSettingsToggle.getAttribute('aria-expanded') === 'true';
  chatSettingsToggle.setAttribute('aria-expanded', String(!isExpanded));
  chatSettings.hidden = isExpanded;
});
chatForm.addEventListener('submit', async event => {
  event.preventDefault();
  const message = chatInput.value.trim();
  if (!message || chatSend.disabled) return;

  appendChatMessage('user', message);
  chatInput.value = '';
  chatSend.disabled = true;
  const typingMessage = appendChatMessage('assistant', 'Sedang menyiapkan jawaban…', 'chat-typing');
  const history = chatHistory.slice(-20);

  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, history })
    });
    const result = await response.json();
    if (!response.ok) {
      const serverError = typeof result?.error === 'string' ? result.error : `Server mengembalikan status ${response.status}.`;
      throw new Error(serverError);
    }
    if (!result || typeof result !== 'object' || typeof result.reply !== 'string' || !result.reply.trim()) {
      throw new Error('Respons backend tidak berisi teks pada properti "reply".');
    }

    typingMessage.remove();
    appendChatMessage('assistant', result.reply.trim());
    chatHistory.push({ role: 'user', content: message }, { role: 'assistant', content: result.reply.trim() });
    if (chatHistory.length > 20) chatHistory = chatHistory.slice(-20);
  } catch (error) {
    console.error('Permintaan ke backend Asisten AI gagal:', error);
    typingMessage.remove();
    const detail = error instanceof Error ? error.message : 'Terjadi kesalahan yang tidak diketahui.';
    appendChatMessage('assistant', `Tidak bisa mendapatkan jawaban dari Gemini. ${detail} Pastikan server aktif dan GEMINI_API_KEY sudah diatur di file .env.`, 'chat-error');
  } finally {
    chatSend.disabled = false;
    chatInput.focus();
  }
});

function appendChatMessage(role, text, extraClass = '') {
  const message = document.createElement('div');
  message.className = `chat-message ${role === 'user' ? 'user-message' : 'assistant-message'} ${extraClass}`.trim();
  if (role !== 'user') {
    const avatar = document.createElement('span');
    avatar.className = 'message-avatar';
    avatar.setAttribute('aria-hidden', 'true');
    avatar.textContent = '✳';
    message.append(avatar);
  }
  const content = document.createElement('p');
  content.textContent = text;
  message.append(content);
  chatMessages.append(message);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  return message;
}

function loadNotes() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored === null) return starterNotes;
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed : starterNotes;
  } catch {
    return starterNotes;
  }
}

function persistNotes() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}

function formatDate(timestamp) {
  const date = new Date(timestamp);
  const today = new Date();
  if (date.toDateString() === today.toDateString()) return `Hari ini, ${date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}`;
  return date.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

function filteredNotes() {
  const query = searchInput.value.trim().toLocaleLowerCase('id');
  let result = notes.filter(note => {
    const matchesText = `${note.title} ${note.body}`.toLocaleLowerCase('id').includes(query);
    const matchesPin = activeFilter !== 'pinned' || note.pinned;
    const matchesColor = activeColor === 'all' || note.color === activeColor;
    return matchesText && matchesPin && matchesColor;
  });
  const sort = document.querySelector('#sort-select').value;
  if (sort === 'title') result.sort((a, b) => a.title.localeCompare(b.title, 'id'));
  else result.sort((a, b) => (sort === 'created' ? b.createdAt - a.createdAt : b.updatedAt - a.updatedAt));
  if (activeFilter !== 'pinned' && sort !== 'title') result.sort((a, b) => Number(b.pinned) - Number(a.pinned) || ((sort === 'created' ? b.createdAt - a.createdAt : b.updatedAt - a.updatedAt)));
  return result;
}

function render() {
  const visible = filteredNotes();
  document.querySelector('#all-count').textContent = notes.length;
  document.querySelector('#pinned-count').textContent = notes.filter(note => note.pinned).length;
  document.querySelector('#footer-count').textContent = `${visible.length} catatan`;
  document.querySelector('#note-summary').textContent = `${notes.length} ${notes.length === 1 ? 'catatan tersimpan' : 'catatan tersimpan'}${notes.some(note => note.pinned) ? ` · ${notes.filter(note => note.pinned).length} disematkan` : ''}`;
  grid.classList.toggle('list-view', activeView === 'list');
  grid.innerHTML = visible.map((note, index) => `
    <article class="note-card ${colors.includes(note.color) ? note.color : 'yellow'}" data-note-id="${escapeHtml(note.id)}" style="animation-delay:${Math.min(index * 45, 250)}ms" tabindex="0" aria-label="Edit catatan ${escapeHtml(note.title || 'tanpa judul')}">
      <div class="note-card-head"><h2>${escapeHtml(note.title || 'Tanpa judul')}</h2><div class="card-menu-wrap"><button class="note-menu" data-action="menu" aria-label="Menu catatan" title="Pilihan lainnya">···</button></div></div>
      ${note.body ? `<p class="note-body">${escapeHtml(note.body)}</p>` : '<p class="note-body" style="color:#999d96;font-style:italic">Catatan kosong</p>'}
      <div class="note-card-foot"><span class="note-date">${formatDate(note.updatedAt)}</span><button class="pin-button ${note.pinned ? 'is-pinned' : ''}" data-action="pin" aria-label="${note.pinned ? 'Lepas sematan' : 'Sematkan catatan'}" title="${note.pinned ? 'Lepas sematan' : 'Sematkan'}">${note.pinned ? '◆' : '◇'}</button></div>
    </article>`).join('');
  const noNotes = visible.length === 0;
  emptyState.hidden = !noNotes;
  grid.hidden = noNotes;
  const searching = Boolean(searchInput.value.trim());
  document.querySelector('#empty-title').textContent = searching ? 'Tidak ada hasil' : notes.length ? 'Tidak ada catatan di sini' : 'Belum ada catatan';
  document.querySelector('#empty-copy').textContent = searching ? 'Coba kata kunci yang berbeda.' : notes.length ? 'Ubah filter atau buat catatan baru.' : 'Mulai dengan menuangkan ide pertamamu.';
  document.querySelector('#empty-add').hidden = searching || (activeFilter === 'pinned' && notes.length > 0) || (activeColor !== 'all' && notes.length > 0);
}

function setFilter(filter) {
  activeFilter = filter;
  document.querySelectorAll('.nav-item').forEach(button => button.classList.toggle('active', button.dataset.filter === filter));
  const label = filter === 'pinned' ? 'Disematkan' : 'Semua catatan';
  document.querySelector('#page-title').innerHTML = `${label}<span class="heading-period">.</span>`;
  document.querySelector('#breadcrumb-title').textContent = label;
  render();
}

function openEditor(note = null) {
  editingId = note?.id ?? null;
  selectedColor = note?.color ?? 'yellow';
  titleInput.value = note?.title ?? '';
  bodyInput.value = note?.body ?? '';
  document.querySelectorAll('.palette-color').forEach(button => button.classList.toggle('selected', button.dataset.noteColor === selectedColor));
  document.querySelector('.editor-label').innerHTML = `<span class="edit-dot"></span> ${editingId ? 'EDIT CATATAN' : 'CATATAN BARU'}${editingId ? ` · ${colorNames[selectedColor] ?? ''}` : ''}`;
  updateCharCount();
  dialog.showModal();
  requestAnimationFrame(() => titleInput.focus());
}

function updateCharCount() {
  document.querySelector('#char-count').textContent = `${bodyInput.value.length} / 4000`;
}

function saveEditor(event) {
  event.preventDefault();
  const title = titleInput.value.trim();
  const body = bodyInput.value.trim();
  if (!title && !body) {
    titleInput.focus();
    return;
  }
  const now = Date.now();
  if (editingId) {
    const note = notes.find(item => item.id === editingId);
    if (note) Object.assign(note, { title, body, color: selectedColor, updatedAt: now });
  } else {
    notes.unshift({ id: crypto.randomUUID?.() ?? String(now), title, body, color: selectedColor, pinned: false, createdAt: now, updatedAt: now });
  }
  persistNotes();
  dialog.close();
  render();
}

function togglePin(noteId) {
  const note = notes.find(item => item.id === noteId);
  if (!note) return;
  note.pinned = !note.pinned;
  note.updatedAt = Date.now();
  persistNotes();
  render();
}

function showCardMenu(card, note) {
  document.querySelectorAll('.card-menu').forEach(menu => menu.remove());
  const wrapper = card.querySelector('.card-menu-wrap');
  const menu = document.createElement('div');
  menu.className = 'card-menu';
  menu.innerHTML = `<button data-menu-action="edit">Edit catatan</button><button data-menu-action="pin">${note.pinned ? 'Lepas sematan' : 'Sematkan'}</button><button class="delete-action" data-menu-action="delete">Hapus catatan</button>`;
  wrapper.append(menu);
  menu.addEventListener('click', event => {
    const action = event.target.closest('button')?.dataset.menuAction;
    if (!action) return;
    if (action === 'edit') openEditor(note);
    if (action === 'pin') togglePin(note.id);
    if (action === 'delete') {
      notes = notes.filter(item => item.id !== note.id);
      persistNotes();
      render();
    }
  });
}

document.querySelector('#add-note').addEventListener('click', () => openEditor());
document.querySelector('#empty-add').addEventListener('click', () => openEditor());
document.querySelector('.close-editor').addEventListener('click', () => dialog.close());
document.querySelector('#editor-form').addEventListener('submit', saveEditor);
bodyInput.addEventListener('input', updateCharCount);
searchInput.addEventListener('input', render);
document.querySelector('#sort-select').addEventListener('change', render);
document.querySelectorAll('.nav-item').forEach(button => button.addEventListener('click', () => setFilter(button.dataset.filter)));
document.querySelectorAll('.color-filter').forEach(button => button.addEventListener('click', () => {
  activeColor = button.dataset.color;
  document.querySelectorAll('.color-filter').forEach(item => item.classList.toggle('selected', item === button));
  render();
}));
document.querySelectorAll('.view-tab').forEach(button => button.addEventListener('click', () => {
  activeView = button.dataset.view;
  document.querySelectorAll('.view-tab').forEach(item => item.classList.toggle('active', item === button));
  render();
}));
document.querySelectorAll('.palette-color').forEach(button => button.addEventListener('click', () => {
  selectedColor = button.dataset.noteColor;
  document.querySelectorAll('.palette-color').forEach(item => item.classList.toggle('selected', item === button));
  document.querySelector('.editor-label').innerHTML = `<span class="edit-dot"></span> ${editingId ? 'EDIT CATATAN' : 'CATATAN BARU'} · ${colorNames[selectedColor]}`;
}));
grid.addEventListener('click', event => {
  const card = event.target.closest('.note-card');
  if (!card) return;
  const note = notes.find(item => item.id === card.dataset.noteId);
  if (!note) return;
  const action = event.target.closest('[data-action]')?.dataset.action;
  if (action === 'pin') {
    event.stopPropagation();
    togglePin(note.id);
  } else if (action === 'menu') {
    event.stopPropagation();
    showCardMenu(card, note);
  } else if (!event.target.closest('.card-menu')) openEditor(note);
});
grid.addEventListener('keydown', event => {
  if ((event.key === 'Enter' || event.key === ' ') && event.target.matches('.note-card')) {
    event.preventDefault();
    const note = notes.find(item => item.id === event.target.dataset.noteId);
    if (note) openEditor(note);
  }
});
document.addEventListener('click', event => {
  if (!event.target.closest('.card-menu-wrap')) document.querySelectorAll('.card-menu').forEach(menu => menu.remove());
});
document.addEventListener('keydown', event => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
    event.preventDefault();
    searchInput.focus();
  }
  if (event.key === 'Escape' && dialog.open) dialog.close();
});
const today = new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date());
document.querySelector('#today-label').textContent = today.toLocaleUpperCase('id-ID');
render();
